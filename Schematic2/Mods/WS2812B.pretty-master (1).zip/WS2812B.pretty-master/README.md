
WS2812B.pretty
==============

LAYOUT FILES: KiCad footprints for WS2812B LEDs (and pin-compatible ones).

This fork has drawings on F.CrtYd layer for automated PCB assembly.

